package com.example.admin.sorting;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Arrays;

public class MainActivity4 extends AppCompatActivity {
EditText et1,et2;
Button b1;

String s[];
int[] b=new int[10];
String[] c=new String[20];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        et1 = (EditText) findViewById(R.id.editText);
        et2 = (EditText) findViewById(R.id.editText2);
        b1 = (Button) findViewById(R.id.button);
        et2.setText(" ");
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n = (et1.getText().toString());
                s = n.split(",");
                sort(s);
                // String[] a =array.split("\\,");
               /* int lenghts=a.length;
           for(int i=0;i<lenghts;i++){
               b[i]= Integer.parseInt(a[i]);

           }
           int len=b.length;

          // Arrays.sort(a);

           for(int i=0;i<lenghts-1;i++){
               for(int j=0;j<lenghts-i-1;j++){
                   if(b[j]>b[j+1]){
                       int temp;
                       temp=b[j];
                       b[j]=b[j+1];
                       b[j+1]=temp;
                   }
               }
           }


          for(int i=0;i<len;i++){
            c[i]=Integer.toString(b[i]);
          }
          int lenc=c.length;
          for(int i=0;i<lenghts;i++){
              et2.setText(a[i]+",");
          }*/
            }
        });
    }
        void sort(String b[]){
            int a[] = new int[b.length];

            int len=b.length;
            for(int i=0;i<b.length;i++)
            {
                a[i]=Integer.parseInt(b[i]);
            }

            int min;
            for (int i=0;i<len-1;i++)
            {
                min=i;
                for(int j=i+1;j<len;j++)
                {
                    if (a[j]<a[min])
                        min=j;
                }
                int temp;
                temp=a[i];
                a[i]=a[min];
                a[min]=temp;

            }

            for(int k=0;k<a.length;k++)
            {
                et2.setText(et2.getText().toString()+Integer.toString(a[k])+" ");
            }

        }

}



