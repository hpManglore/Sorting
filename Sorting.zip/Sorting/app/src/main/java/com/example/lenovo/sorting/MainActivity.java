package com.example.lenovo.sorting;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText input;
    private TextView output;
    private Button submit;
    private String[] inparray1;
    private int[] inparray2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input = findViewById(R.id.input);
        output = findViewById(R.id.output);
        submit = findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(input.getText().toString().isEmpty()) return;
                inparray1 = input.getText().toString().split("\\s+");
                inparray2 = new int[inparray1.length];
                for (int i=0;i<inparray1.length;i++) {
                     inparray2[i] = Integer.parseInt(inparray1[i]);

                }
                for(int i=0;i<inparray2.length;i++) {
                    boolean flag = false;
                    for(int j=0;j<inparray2.length-1-i;j++) {
                        if(inparray2[j]>inparray2[j+1]) {
                            int temp = inparray2[j];
                            inparray2[j] = inparray2[j+1];
                            inparray2[j+1] = temp;
                            flag = true;
                        }
                    }
                    if(!flag) break;
                }
                String op="";
                String reop="";
                for(int i=0;i<inparray2.length;i++) {
                    op = op + " " + inparray2[i];
                    reop = reop + " "+inparray2[inparray2.length-i-1];
                }
                output.setText("Ascending Order:"+op+"\n"+"Descending Order:"+reop);

            }
        });
    }
}
